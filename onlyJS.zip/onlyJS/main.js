var fs=require("fs");
var server=require("http");
server.createServer(engine).listen(8091);
console.log();
var response=require("./methods");
var data=fs.readFileSync("demo.csv").toString();
console.log(data.toString());
var jsondata=response.data.csvJSON(data);
console.log("------------------------------");
console.log(jsondata);
fs.writeFileSync("data.json",jsondata);
function engine(request,response)
{
  response.writeHead(200,{'Content-type':'text/html'});

if((request.method=="GET")&& (request.url="/"))
{
  fs.createReadStream("./index.html").pipe(response);
}
else {
  response.end("hello data");
}

}
